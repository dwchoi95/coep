def remove_extras(lst):
    newlist=[]
    for i in lst:
        if i not in newlist:
            newlist += [i,]
    return newlist
